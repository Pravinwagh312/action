""" importing required modules """
# pylint: disable=W0703
# pylint: disable=
import os
import argparse
import json
import sys
import requests
import qualityGateModule
import testStdModule
import producerModule
# import licenseModule
import artifactMgnModule

# ----- All required functions ------ #
def get_current_job():
    """ getting the current job """
    github_job = os.getenv('GITHUB_JOB')
    if github_job:
        return github_job
    else:
        error = {
                "ts": {
                'error': 'MG_E107',
                'description': "GITHUB_JOB environment variable is not set."}}
        error_to_json(error)
        sys.exit()
    # raise ValueError("GITHUB_JOB environment variable is not set.")


def error_to_json(error_msg):
    """Writes error details to a JSON file in a specified directory."""
    curr_dir = os.getcwd()
    errordir = curr_dir
    os.makedirs(errordir, exist_ok=True)  # Ensures the directory exists
    err_filename = os.path.join(errordir, 'errors.json')
    with open(err_filename, "w") as file:
        json.dump(error_msg, file, indent=4)
    print(f"Errors written to: {err_filename}")

def load_workflow_config():
    """ Loading workflow details """
    workflowname = os.getenv('GITHUB_WORKFLOW')
    # workflowname = 'gayatri_AP'
    print('Workflow name after split', workflowname)
#     workflowname = "gayatri_AP_Integration" # remove this
    if not workflowname:
        error_msg = {
                "ts": {
                'error': 'MG_E106',
                'description': "GITHUB_WORKFLOW environment variable is not set."}}
        error_to_json(error_msg)
        sys.exit()
       
    return workflowname

def get_github_api_url():
    """ getting github api url """
    server_url = os.getenv('GITHUB_SERVER_URL')
    print(server_url)
    if server_url:
        # Assuming the standard API path. Adjust if necessary.
        api_base_path = "/api/v3"
        return f"{server_url}{api_base_path}"
    else:
        error_msg = {
                "ts": {
                'error': 'MG_E103',
                'description': "GITHUB_SERVER_URL environment variable is not set."}}
        error_to_json(error_msg)
        sys.exit()

def get_repository_name():
    """ getting repository name """
    github_repo = os.getenv('GITHUB_REPOSITORY')
    if github_repo:
        # Extracting the repository name from the 'GITHUB_REPOSITORY' value
        repo_name = github_repo.split('/')[-1]
        #print('repo name is ==> ', repo_name)
        return repo_name
    else:
        error_msg = {
                "ts": {
                'error': 'MG_E104',
                'description': "GITHUB_REPOSITORY environment variable is not set."}}
        error_to_json(error_msg)
        sys.exit()

def get_current_branch():
    """ getting current branch """
    github_ref = os.getenv('GITHUB_REF_NAME')
    print('branch Name -> ', github_ref)
    if github_ref:
        branch_name = github_ref
        return branch_name
    else:
        error_msg = {
                "ts": {
                'error': 'MG_E105',
                'description': "GITHUB_REF environment variable is not set."}}
        error_to_json(error_msg)
        sys.exit()   

# Function to parse arguments
def parse_arguments():
    parser = argparse.ArgumentParser(__name__)
    parser_github = parser.add_argument_group("github")
#     parser_github.add_argument("-wf", "--workflow_name")
    parser_github.add_argument("-wd", "--github-workingDir", help='Action Dir containing req files to execute code')
    # parser_github.add_argument("-cfn", '--config-name', help='name of configuration from dashboard', required=True)
    return parser.parse_args()

# Function to set up environment variables for GitHub actions
# def setup_environment(arguments):
#     os.environ['GITHUB_WORKFLOW'] = str(arguments.workflow_name)
#     os.environ['GITHUB_SERVER_URL'] = 'https://github.com'
#     os.environ['GITHUB_REPOSITORY'] = "CICD_Framework_and_KPI"
#     os.environ['GITHUB_JOB'] = 'jobname1'
#     os.environ['GITHUB_REF_NAME'] = "main"

# Function to call API and retrieve workflow configuration
def get_workflow_config(api_url_base, workflow_name,repository_name,current_job,current_branch):
# def get_workflow_config(api_url_base, workflow_name):
    #full_url = f"{api_url_base}?workflowName={workflow_name}&repoName={repository_name}&jobName={current_job}&branchName={current_branch}"
    full_url = f"{api_url_base}?workflowName={workflow_name}"
    print('full url', full_url)
    response = requests.get(full_url)
    if response.status_code == 200:
        apidata = response.json()
        print('api data is --> ',apidata)
        return apidata
    else:
        error = {
            "ts": {
                'error': 'MG_E101',
                'description': f"Failed to get API response with response code {response.status_code}"
            }
        }
        error_to_json(error)
        sys.exit()

# Function to execute test standardization
def execute_test_standardization(tsdata, cwd):
    ts = testStdModule.TestStandardization(cwd)
    ts.read_json(tsdata)
    ts.write_json(ts.json_output)
    return ts.output_directory + '/output.json'


def calculate_quality_gate(tsinput, qginput, refdata, workflow_name, cfn, current_job, apidata, cwd):
    """
    Calculates the quality gate for the provided input data.
    """
    print('\n####### Quality Gate calculations  starts now .... #######\n\n')
    
    allqualitydata = {}
    allqualitydata1 = {}
    tsinput1 = {}

    for key in tsinput.keys():
        tsinput1['key'] = tsinput[key]
        print(' Step-1: Initializing the data')
        qg = qualityGateModule.qualityGate(qginput, tsinput1, refdata)
        qg.testfilename = key
        qg.producerdata['quality_data'] = {}
        qg.producerdata['quality_data'][key] = {workflow_name:{}}
        qg.execute()
        qg.verdict()
        qg.finalresult()
        allqualitydata.update(qg.producerdata['quality_data'])

    # license_data = apidata[workflow_name][cfn][current_job]['license']
    # lsmg = licenseModule.LicenseInfo(license_data)
    # lsmg.fetch_versions()
    # licensejson = lsmg.output
    # license_file = os.path.join(cwd, 'licenseData.json')
    # print("--> license file ", license_file)
    allqualitydata1['quality_data'] = allqualitydata.copy()

    # for key in allqualitydata.keys():
    #     allqualitydata1["quality_data"][key][workflow_name]['license'] = licensejson

    return allqualitydata1


# Function to handle artifact management
def manage_artifacts(cwd, xmlfilepath):
    artifactdata = artifactMgnModule.ArtifactDetails(cwd, xmlfilepath)
    zip_file = artifactdata.compressed_artifact_data()
    artifactdata.upload_artifacts(zip_file)
    artifactdata.fetch_artifact_metadata(zip_file)
    return
    
    

# Main function
def main():
    arguments = parse_arguments()
#     setup_environment(arguments)
    for key, value in os.environ.items():
        if "GITHUB" in key:  # Filter to only include GitHub-specific variables
            print(f"{key}: {value}")

	
    #change the IP of API
    #api_url_base = 'http://10.52.52.209:30080/workflow-config/get-config-by-wf-name'
    api_url_base = 'http://localhost:8080/workflow-config/get-config-by-wf-name'

    #Retrieving the github reference data
    try:
        github_api_url = get_github_api_url()
        print(f"GitHub API URL: {github_api_url}")
        workflow_name = load_workflow_config()
        repository_name = get_repository_name()
        current_branch = get_current_branch()
        current_job = get_current_job()

        refdata = {
            'workflowname': workflow_name,
            'repository': repository_name,
            'branch': current_branch,
            'jobname': current_job
        }
        print(f"Reference data from GitHub: {refdata}")

    except Exception as exeptional_error:
        print(f"Error: {exeptional_error}")

    # workflow_name = os.getenv('GITHUB_WORKFLOW')
    # print('Workflow name to python is -> ', workflow_name)
    # cfn = str(arguments.config_name)
    cwd = str(arguments.github_workingDir)
    
    
    #commenting the config name as per the requirements
    # print('This is configuration Name -> ' ,cfn)

#     apidata = get_workflow_config(api_url_base, workflow_name)
    apidata = get_workflow_config(api_url_base, workflow_name, repository_name, current_job, current_branch)
    
    #Trying to collect license data seperately and omiting it for further use
    try:
        license_data = apidata[workflow_name]['license']
        # print(license_data)
        outputfilename =  os.path.join(cwd, 'licenseData.json')
        with open(outputfilename,"w") as license_file:
            json.dump(license_data,license_file, indent=4)
        del apidata[workflow_name]['license']
    except:
        raise "failed to get license data"
    # print(apidata)

    #listing out all the config names from the json file
    cfn = list(apidata[workflow_name].keys())[0]
    # print(cfn)
    # Test Standardization
    print('\n####### Test Standardization starts .... #######\n\n')
    current_job = get_current_job()  # You would need to define or import this function
    print('current job name is --> ', current_job)
    try:
        tsdata = apidata[workflow_name][cfn][current_job]['testStd']
        # print('this data is for ts -->  ', tsdata)
    except KeyError:
        error = {
                 "ts": {
                 'error': 'MG_E102',
                 'description': f"Configurations are missing for current job {current_job}."}}
        error_to_json(error)
        sys.exit()
    outputdir = execute_test_standardization(tsdata, cwd)
    print('\n\n ####### Test Standardization ends .... #######\n\n')

    # Quality Gate calculations
    # try:
    #     github_api_url = get_github_api_url()
    #     print(f"GitHub API URL: {github_api_url}")
    #     workflow_name = load_workflow_config()
    #     repository_name = get_repository_name()
    #     current_branch = get_current_branch()
    #     current_job = get_current_job()

    #     refdata = {
    #         'workflowname': workflow_name,
    #         'repository': repository_name,
    #         'branch': current_branch,
    #         'jobname': current_job
    #     }
    #     print(f"Reference data from GitHub: {refdata}")

    # except Exception as exeptional_error:
    #     print(f"Error: {exeptional_error}")

    # if workflow_name:  
    qginput = apidata
    # else:
    #     error = {
    #          "ts": {
    #          'error': 'MG_E109',
    #          'description': "GITHUB_WORKFLOW environment variable is not set or is empty."}}
    #     error_to_json(error)
    #     sys.exit()

    try:
        with open(outputdir,'r') as ts:
            tsinput = json.load(ts)
     
    except FileNotFoundError:
        error = {
             "ts": {
                 'error': 'MG_E108',
                 'description': "Test standardization output file not found"}}
        error_to_json(error)
        sys.exit()
    allqualitydata = calculate_quality_gate(tsinput, qginput, refdata, workflow_name, cfn, current_job, apidata, cwd)

    # Write quality data to file
    qualityfile = os.path.join(cwd, 'quality.json')
    with open(qualityfile, "w") as g:
        json.dump(allqualitydata, g, indent=4)
    print('quality data is saved here --> ', qualityfile)
    print('\n\n####### Quality Gate calculations  ends .... #######\n\n')

    # Artifact Management
    print("\n\n###### Artifact Management starts ######\n\n")
    manage_artifacts(cwd, tsdata["xmlFilePath"])
    print("\n\n###### Artifact Management ends ######\n\n")


    # Log success
    while True:
        error_file_path = os.path.join(os.getcwd(),"errors.json")
        print(error_file_path)
        if os.path.exists(error_file_path):
            with open(error_file_path, "r") as error_file:
                error_check = json.load(error_file)
            if error_check:
                error_to_json(error_check)
        else:
            error = {
                "All": {
                'error': 'E0',
                'description': "Script executed successfully"}}
            error_to_json(error)
        break

if __name__ == "__main__":
    try:
        main()
    except:
        print("main function failed")
    finally:
        current_job = get_current_job()
        github_run_id = os.getenv('GITHUB_RUN_ID')
        print("full job name is ==> ",os.getenv('JOB_NAME'))
        INTEGRATOR = producerModule.GitHubKafkaIntegrator(current_job, github_run_id)
        INTEGRATOR.run()
