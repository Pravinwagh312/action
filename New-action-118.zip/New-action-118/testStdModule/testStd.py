"""
This script provides functionalities for processing and standardizing test reports.
It supports reading XML and CSV files, extracting relevant data based on JSON configurations,
and writing the processed data to output JSON files. It includes error handling and
command-line argument parsing for specifying file paths and configurations.
"""
# pylint: disable=W0703

import os
import sys
import json
import pandas as pd
import xmltodict

class TestStandardization:
    """
    This class is designed to process XML and CSV files based
    on configurations specified in JSON files.
    It handles file operations, data extraction, and
    error handling, providing functionalities to read,
    write, and manage data according to specified configurations.
    
    A class used to standardize test reports from various file formats.

    Attributes:
    ----------
    cwd : str
        The current working directory.
    jsonfilename : str
        The name of the JSON output file.
    error : dict
        A dictionary to store error messages.
    json_output : dict
        A dictionary to store the standardized test report data.
    output_directory : str
        The directory where the output file will be saved.
    file : str
        The name of the file being processed.

    Methods:
    -------
    error_to_json()
        Writes the error message to a JSON file.
    write_json(json_dict)
        Writes the standardized test report data to a JSON file.
    cleanup(dict_obj, keys)
        Removes unnecessary keys from a dictionary.
    read_xml(xmlfile, data, json_all_data, file)
        Reads an XML file and standardizes its data.
    readcsv(csv_file_path)
        Reads a CSV file and standardizes its data.
    read_json(json_file)
        Reads a JSON file and standardizes its data.
    """

    def __init__(self, init_cwd):
        """
        Initializes the TestStandardization class.

        Parameters:
        ----------
        init_cwd : str
            The initial current working directory.
        """
        self.cwd = init_cwd
        self.jsonfilename = ''
        self.error = {}
        self.json_output = json.loads('{}')
        self.output_directory = ''
        self.file = ''

    def error_to_json(self):
        """
        Writes the error message to a JSON file.

        If the error dictionary is empty, it sets a default error message.
        Otherwise, it writes the error message to a JSON file named 'errors.json'.
        """
        if bool(self.error) == False:
            # Set a default error message if the error dictionary is empty
            self.error['ts'] = {}
            self.error['ts']['error'] = 'E0'
        else:
            # Write the error message to a JSON file
            err_filename = os.path.join(self.cwd, 'errors.json')
            with open(err_filename, "w") as error_file:
                json.dump(self.error, error_file, indent=4)
            print(json.dumps(self.error, indent=4))

    def write_json(self, json_dict):
        """
        Writes the standardized test report data to a JSON file.

        Parameters:
        ----------
        json_dict : dict
            The standardized test report data.
        """
        print(' Step-3: Writing output of test standardization ..')
        if len(json_dict) != 0:
            # Convert the dictionary to a JSON string
            json_object = json.dumps(json_dict, indent=4)
            self.output_directory = self.cwd
            jsonfilename = os.path.join(self.output_directory, 'output.json')
            print('\n     You can find output file here \n ', json_object)
            # Write the JSON string to a file
            with open(jsonfilename, "w") as outfile:
                outfile.write(json_object)

    def cleanup(self, dict_obj, keys):
        """
        Removes unnecessary keys from a dictionary.

        Parameters:
        ----------
        dict_obj : dict
            The dictionary to clean up.
        keys : list
            The keys to keep in the dictionary.
        """
        for key in list(dict_obj.keys()):
            if not isinstance(dict_obj, dict):
                continue
            elif key not in keys:
                # Remove the key if it's not in the list of keys to keep
                dict_obj.pop(key, None)
            elif isinstance(dict_obj[key], dict):
                # Recursively clean up nested dictionaries
                self.cleanup(dict_obj[key], keys)
            elif isinstance(dict_obj[key], list):
                # Clean up lists of dictionaries
                for item in dict_obj[key]:
                    self.cleanup(item, keys)

    def read_xml(self, xmlfile, data, json_all_data, file):
        """
        Reads an XML file and standardizes its data.

        Parameters:
        ----------
        xmlfile : str
            The path to the XML file.
        data : dict
            The configuration data.
        json_all_data : dict
            The standardized test report data.
        file : str
            The name of the file being processed.
        """
        print(' Step-2: Processing xml file start ..')
        try:
            # Get the list of tags to keep
            mylist = []
            for tag in data['tags']:
                mylist += list(data['tags'][tag])
            # Parse the XML file
            with open(xmlfile, mode='r', encoding='cp932', errors='ignore') as xml_file:
                data_dict = xmltodict.parse(xml_file.read(), attr_prefix='', cdata_key='')
                json_all_data = data_dict
                # Clean up the parsed data
                self.cleanup(json_all_data, mylist)
                if len(json_all_data) != 0:
                    # Add the cleaned up data to the output dictionary
                    self.json_output[file] = json_all_data
                else:
                    # Set an error message if the data is empty
                    self.error['ts'] = {}
                    self.error['ts']['error'] = 'TR_E103'
                    self.error['ts']['description'] = "Error parsing XML file"
                    self.error_to_json()
                    sys.exit()
        except xmltodict.expat.ExpatError as e:
            # Set an error message if there's a parsing error
            self.error['ts'] = {}
            self.error['ts']['error'] = 'TR_E103'
            self.error['ts']['description'] = f"Error parsing XML file: {str(e)}"
            self.error_to_json()
            sys.exit()
            raise

    def readcsv(self, csv_file_path):
        """
        Reads a CSV file and standardizes its data.

        Parameters:
        ----------
        csv_file_path : str
            The path to the CSV file.
        """
        # Try different encodings to read the CSV file
        encodings = ['utf-8', 'ISO-8859-1', 'cp1252', 'latin1']
        for encoding in encodings:
            try:
                # Read the CSV file
                dataframe = pd.read_csv(csv_file_path, encoding=encoding)
                total_rows = dataframe.shape[0]
                # Add the CSV data to the output dictionary
                self.json_output[csv_file_path] = {
                    "total rows": total_rows,
                    "header rows": 1,
                    "violations": total_rows - 1
                }
                return
            except pd.errors.EmptyDataError:
                # Set an error message if the CSV file is empty
                self.error['ts'] = {
                    'error': 'TR_E104',
                    'description': 'CSV file is empty.'
                }
                self.error_to_json()
                sys.exit()
                raise
            except pd.errors.ParserError as e:
                print(f"Unable to read CSV file with encoding {encoding}: {e}")
            except Exception as e:
                print(f"An unexpected error occurred while trying to read the CSV file with encoding {encoding}: {e}")
                break
        # Check if the CSV file was successfully read
        if csv_file_path not in self.json_output:
            # Set an error message if the CSV file was not read
            self.error['ts'] = {
                'error': 'TR_E104',
                'description': 'Failed to read the csv test report file.'
            }
            self.error_to_json()
            sys.exit()

    def read_json(self, json_file):
        """
        Reads a JSON file and standardizes its data.

        Parameters:
        ----------
        json_file : dict
            The configuration data.
        """
        print(' Step-1: reading configuration form dashboard API ...')
        json_all_data = {}
        data = json_file
        print('all ts data keys ', data.keys())
        try:
            # Get the XML file path
            xmlname = data['xmlFilePath']
            xmlfilepath = os.path.join(self.cwd, xmlname)
            print('     XMl path is --> ', xmlfilepath)
            # Get the file types to process
            file_types = data["filetype"]
            xml_processed = False
            csv_processed = False
            # Process each file in the XML file path
            for file in os.listdir(xmlfilepath):
                print(file)
                if file.endswith(".csv") and "csv" in file_types:
                    # Process CSV files
                    csv_file_path = os.path.join(xmlfilepath, file)
                    self.readcsv(csv_file_path)
                    csv_processed = True
                elif file.endswith(".xml") and "xml" in file_types:
                    # Process XML files
                    self.read_xml(os.path.join(xmlfilepath, file), data, json_all_data, file)
                    xml_processed = True
                else:
                    print('     Not Processing these files :', file)
        except Exception:
            # Set an error message if there's an exception
            self.error['ts'] = {}
            self.error['ts']['error'] = 'TR_E101'
            self.error['ts']['description'] = 'Directory not found/Incorrect path specified.'
            self.error_to_json()
            sys.exit()
        # Check if any files were processed
        if not csv_processed and not xml_processed:
            # Set an error message if no files were processed
            self.error['ts'] = {}
            self.error['ts']['error'] = 'TR_E102'
            self.error['ts']['description'] = 'No test report found'
            self.error_to_json()
            sys.exit()
