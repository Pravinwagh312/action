"""
This script provides functionalities for processing and standardizing
test reports.It supportsreading XML and CSV files, extracting relevant 
data based on JSON configurations,and writingvthe processed data to 
output JSON files. It includes error handling and command-line argument
parsing for specifying file paths and configurations.Implements quality
gate evaluations for software testing, determining if tests meet defined 
criteria. Utilizes configuration inputs,reference data,and test standards
to produce pass/fail verdicts.
"""
# pylint: disable=W0703
import json
import os
import sys
import operator
import pandas as pd
from flatten_json import flatten

class qualityGate:
    """
    This class is designed to process XML and CSV files based
    on configurations inputs,reference data,and test standards
    to produce pass/fail verdicts.
    """

    def __init__(self,qginput, tsinput,refdata):
        self.qginput = qginput
        self.tsinput = tsinput
        self.error = {}
        #print(self.tsinput)
        self.ops = {
    '+': operator.add,
    '-': operator.sub,
    '<': operator.lt,
    '<=':operator.le,
    '==':operator.eq,
    '!=':operator.ne,
    '>=':operator.ge,
    '>': operator.gt
    }
        self.producerdata = {}
        self.tsresults = {}
        self.inputs = {}
        self.columnnames  = {}
        self.testname = ""
        self.extract = {}
        self.attribute = ""
        self.attributename = ""
        self.function1 = ""
        self.processed = ''
        self.result = ""
        self.verdictinput = ""
        self.preverdict = {}
        self.finalverdict = ''
        self.verdictsummary = {}
        self.refdata = refdata
        self.threshold = ''
        self.jobname = ''
        self.testfilename = ''
        self.wname = ''
        self.branch = ''
        self.df = pd.DataFrame()
        self.attrib_value = ''

    def error_to_json(self, error_data):
        """Writes error details to a JSON file in a specified directory."""
        cwd = os.getcwd()
        errordir = os.path.join(cwd)
        os.makedirs(errordir, exist_ok=True)  # Ensures the directory exists
        err_filename = os.path.join(errordir, "errors.json")
        #error_data = self.error if self.error else {'qg': {'error': 'E0'}}
        with open(err_filename, "w") as f:
            json.dump(error_data, f, indent=4)
        print(error_data)
        print(f"Errors written to: {err_filename}")

    def flatit(self):
        """
        Flattens input JSON structures into a pandas DataFrame and saves the result as a CSV file,
        handling data format and file writing errors.
        """
        try:
            # Opening JSON file
            #print (' input block --> ', self.tsinput[self.testfilename])
            toflat = [self.tsinput[x] for x in self.tsinput]
            #print('flat it --> ',toflat,self.tsinput[self.testfilename].keys())
            dic_flattened = [flatten(d) for d in toflat]
            #print('flatten --> ', dic_flattened)
            self.df = pd.DataFrame(dic_flattened)
            #print('data frame is ->\n' , self.df)
            self.df.to_csv('out.csv')
            #new_df = pd.concat(df2)
        except TypeError as e:
            error_data = {
                'ts': {
                    'error': 'QG_E102',
                    'description': f"Error in data format: {e}"
                }
            }
            self.error_to_json(error_data)
            sys.exit()
        except (IOError, OSError) as e:
            error_data = {
                'ts': {
                    'error': 'QG_E103',
                    'description': f"File writing error: {e}"
                }
            }
            self.error_to_json(error_data)
            sys.exit()

    def alltests(self):
        """
        Parses and extracts specific test attribute values from a DataFrame based on configuration,
        signaling errors for incorrect configurations or attributes.
        """
        avalue = (self.inputs[self.testname]['attrib'])
        df2 = self.df.columns.tolist()
        # print("df2 == ",df2)
        for key,ivalue in avalue.items():
            partcolumns = []
            for i in df2:
                if i.endswith(ivalue):
                    #print(" Found ----> ", ivalue, "i is --> ",i)
                    sep = str(self.inputs[self.testname]['attrib_sep'])
                    #print('prob --->  ',self.df.loc[self.count,i])
                    instance = (','.join(map(str, self.df[i].tolist())).split(sep))
                    #print('instance -> ',instance)
                    partcolumns.append(instance)
                    #print('print part coulmne --> ', partcolumns)
            self.columnnames[key] = partcolumns
        # if len(self.columnnames) == 0:
        #     error_data = {
        #         'ts': {
        #             'error': 'QG_E107',
        #             'description': 'Test standardization file is incorrect.'
        #         }
        #     }
        #     self.error_to_json(error_data)
        #     #print("column name is --> ",self.columnNames)
        #     sys.exit()
        #print("column name is --> ",self.columnNames)

    def get_job_data(self):
        """Retrieves and evaluates job data based on configured quality gates"""
        print(' Step-3: Matching GitHub and KPI dashboard information ..')
        #print(qginput)
        jobdata = []
        # if self.qginput is not None:
        branch_found = False
        # repo_found = False
    #else:
        #print("workflow quality gate configuration incorrect")
        if self.refdata['workflowname'] in self.qginput.keys():
            self.wname = self.refdata['workflowname']
            self.producerdata['quality_data'][self.testfilename]['workflowname'] = self.wname
            #print('workflow name => ',wname)
            #if self.refdata['configname'] in self.qginput[wname]:
            # for i in self.qginput[self.wname]:
            # list(apidata[workflow_name].keys())[0]
            config = list(self.qginput[self.wname].keys())[0]
            self.producerdata['quality_data'][self.testfilename]['configname'] = config
            print('config name is --> ',config)
                #print(branch)
                # repo_found = False  # Initialize a flag for repository found status
            if 'repo' in self.qginput[self.wname][config] and\
                    self.refdata['repository']== self.qginput[self.wname][config]['repo']:
                #print('repo Done  -- >')
                # repo_found = True
                self.producerdata['quality_data'][self.testfilename]['repo'] = self.refdata['repository']
            else:
                error_data = {
                    'ts': {
                        'error': 'QG_E108',
                        'description': 'Mismatch in repository name'}}
                self.error_to_json(error_data)
                sys.exit()

            print('list of branches',self.qginput[self.wname][config]['branch'])
            for branch in self.qginput[self.wname][config]['branch']:
                if self.refdata['branch'] == branch:
                    branch_found = True
                    self.tsresults['branch'] = self.refdata['branch']
                    self.branch = self.tsresults['branch']
                    print('self.branch',self.branch)
                    self.producerdata['quality_data'][self.testfilename]['branchname'] = self.branch
                    print('branch Name Done  -- >')
                    print('producerdata',self.producerdata)
                    if self.refdata['jobname'] in self.qginput[self.wname][config]:
                        self.jobname = self.refdata['jobname']
                        self.tsresults['jobname'] =  self.refdata['jobname']
                        job =  self.refdata['jobname']
                        jobdata = self.qginput[self.wname][config][job]
                        #print("job is ->", job)
                        self.verdictinput = self.qginput[self.wname][config][job]['qg']['verdict']
                    # else:
                    #     error_data = {
                    #         'ts': {
                    #             'error': 'QG_E102',
                    #             'description': 'Mismatch in jobname'
                    #         }
                    #     }
                    #     self.error_to_json(error_data)
                    #     sys.exit()

            if not branch_found:
                error_data = {
                    'ts': {
                        'error': 'QG_E101',
                        'description': 'Mismatch in branch name'}}
                self.error_to_json(error_data)
                sys.exit()

        # else:
        #     error_data = {
        #         'ts': {
        #             'error': 'QG_E102',
        #             'description': 'workflow name for quality gate configuration is incorrect'
        #         }
        #     }
        #     self.error_to_json(error_data)
        #     sys.exit()
            #print(' Incorrect Test Standardization file ')
        # else:
        #     error_data = {
        #         'ts': {
        #             'error': 'QG_E101',
        #             'description': 'workflow configuration of quality gate are incomplete'
        #         }
        #     }
        #     self.error_to_json(error_data)
        #     sys.exit()
        #print('jobdata is ->', jobdata['qg'])
        #self.producerdata['quality_data'][self.testfilename][self.wname] = jobdata
        self.producerdata['quality_data'][self.testfilename][self.wname] = jobdata.copy()
        return jobdata

    # Extract values from the processed result
    def extractresult(self):
        """Extracts test results based on configured attributes and indices"""
        print(' Step-4: Extract results based on configuration set in dashboard')
        result = {}
        #print(inputs[testname]['instance'])
        avalue = (self.inputs[self.testname]['attrib'])
        for key,_ in avalue.items():
            #print(key, ivalue)
            temp = []
            #if 'single'self.inputs[self.testname]['index'] == 'singleValue':
            for ix in self.inputs[self.testname]['index'].values():
                try:
                    #print('index -> ', ix)
                    # if ix == None:
                    #     error_data = {
                    #         'ts': {
                    #             'error': 'QG_E108',
                    #             'description': 'workflow configuration Index is empty'}}
                    #     self.error_to_json(error_data)
                    #     sys.exit()
                        #print("index empty")
                    if str(ix[0]) == 'singleValue':
                        #print('columnName for single value ---> ',self.columnnames[key] )
                        result[key] = self.columnnames[key][0]

                    #elif self.inputs[self.testname]['index'] == 'All':
                    elif str(ix[0]) == 'All':
                        #print('I am in ---> ')
                        #result[key] = self.columnnames[ivalue][0]
                            #result.append(i[0])
                        temp2 = []
                        for i in self.columnnames[key]:
                            temp2.append(i[0])
                        result[key] = temp2
                        #print('testname ', testname, 'result => ', result)
                        #return(result)
                    #elif type((list(*self.inputs[self.testname]['index'].values())[0])) is int:
                    elif len(list(*self.inputs[self.testname]['index'].values())) > 1 :
                        index = list(*self.inputs[self.testname]['index'].values())
                        #print('=====> ',int(index[0]),index[1] )
                        #print('value is =>', values)
                        #print("column value -> ",(self.columnnames[key]))
                        temp.append(self.columnnames[key][int(index[0])-1][int(index[1])-1])
                        result[key] = temp
                    # else:
                    #     error_data = {
                    #         'ts': {
                    #             'error': 'QG_E113',
                    #             'description': "workflow configuration Indexes is incorrect"}}
                    #     self.error_to_json(error_data)
                    #     sys.exit()
                        #print("incorrect index")
                    if len(result[key]) == 0:
                        error_data = {
                            'ts': {
                                'error': 'QG_E104',
                                'description': f"Error: workflow configuration attributes\
                                      are incorrect for key '{key}'"
                            }
                        }
                        self.error_to_json(error_data)
                        sys.exit()
                except IndexError:
                    error_data = {
                        'ts': {
                            'error': 'QG_E104',
                            'description': f"Error: workflow configuration attributes\
                                  are incorrect for key '{key}'"
                        }
                    }
                    self.error_to_json(error_data)
                    sys.exit()
                    #print(f"Error: Index out of range for key '{key}'")
        print("Result -------> ",len(result),' ', result)
        return result

    #------------------Evaluation functions starts---------------------------------------
    def extractSingleValue(self):
        """extracting attribute single value"""
        return(self.extract)

    def extractSingleResult(self):
        """Compares extracted attribute values against test standards to assign numerical results."""
        result = {}
        for attrib_value in self.extract.values():
            #print(' from input => ', self.attrib_value, 'From TS -> ', *attrib_value  )
            attrib_value = "".join(attrib_value)
            if self.attrib_value == (attrib_value):
                result['result'] = ['100']
            else:
                result['result'] = ['0']
        return(result)

    def resultPercentage(self):
        """Calculates the percentage of attributes matching a specific value within extracted results."""
        countratio = {}
        for i in self.extract.values():
            #print("inside count function", i, len(i), i.count(self.attrib_value) )
            countratio['result'] = [i.count(self.attrib_value)/len(i) * 100]

        return(countratio)

    def ratio(self):
        """Computes the ratio of 'Numerator' to 'Denominator' from extracted data,\
              handling division by zero."""
        ndratio = {}
        if self.extract['Denominator'][0] == "0":
            ndratio['result'] = ['100']
        else:
            ndratio['result'] = [(int(self.extract['Numerator'][0])/int\
                                  (self.extract['Denominator'][0]) * 100)]
        return(ndratio)
    # ------------------ Evaluation functions ends---------------------------------------

    def processresult(self):
        """process the results  and select funtions"""
        print(' Step-5: Process the extracted data ....')
        return getattr(self,self.function1)()

    def compareresult(self):
        """Compare results with threshold"""
        print(' Step-5: Compare the result with threshold set in the Dashboard ..')
        for _,avalue in self.processed.items():
            avalue1 = int(*avalue)
            #print("type of value", key,avalue,type(avalue))
            operators = self.inputs[self.testname]['operator']
            #print(self.inputs[self.testname]['threshold'])
        if self.ops[operators](avalue1, int(self.inputs[self.testname]['threshold'])):
            resultstatus = 'pass'
            #print('Pass')
        else:
            resultstatus = 'fail'
            #print('Fail')
        return resultstatus

    def verdict(self):
        """Evaluates final verdict based on 'AND'/'OR' conditions in verdictinput against\
              preverdict results."""
        print(' Step-6: Extracting final verdict ..')
        # if not self.verdictinput or ('AND' not in self.verdictinput and 'OR'\
        #                               not in self.verdictinput):
        #     error_data = {
        #         'ts': {
        #             'error': 'QG_E110',
        #             'description': 'All tests are inactive'}}
        #     self.error_to_json(error_data)
        #     sys.exit()
            #raise ValueError("Error: All tests are inactive or verdictinput\
            #  is not properly defined.")
        self.verdictsummary['AND'] = 'NA'
        self.verdictsummary['OR'] = 'NA'

        if "AND" in self.verdictinput.keys():
            for i in self.verdictinput["AND"]:
                if i == "NA" or len(i) == 0:
                    self.verdictsummary['AND'] = 'NA'
                elif self.preverdict[i] == 'pass':
                    self.verdictsummary['AND'] = 'pass'
                else:
                    self.verdictsummary['AND'] = 'fail'
                    break

        elif "OR" in self.verdictinput.keys():
            for i in self.verdictinput["OR"]:
                #print('preverdict -->', i)
                if i == 'NA' or len(i) == 0:
                    self.verdictsummary['OR'] = 'NA'
                elif self.preverdict[i] == 'pass':
                    self.verdictsummary['OR'] = 'pass'
                else:
                    self.verdictsummary['OR'] = 'fail'
                    break
        else:
            self.verdictsummary['AND'] = 'NA'
            self.verdictsummary['OR'] = 'NA'

        if len(self.verdictsummary) == 0:
            print("verdict in input not found")
        else:
            print('     Summary verdict --> ',self.verdictsummary)

        if self.verdictsummary['AND'] == 'pass' or self.verdictsummary['OR'] in ['pass']:
            #print('inpass')
            self.finalverdict = 'pass'
        else:
            #print('infail')
            self.finalverdict = 'fail'

        self.producerdata['quality_data'][self.testfilename]['final_verdict'] = self.finalverdict
        #print('Final Vedict is => ', self.finalverdict)

    def finalresult(self):
        """Serializes the aggregated quality data to a JSON file, handling serialization and\
              file writing errors."""
        try:
            # jsondata = json.dumps(self.producerdata)
            # #print('---> ',jsondata)
            qualityfile = os.path.join(os.getcwd(),'quality.json')
            #print('quality file path --> ', qualityfile)
            with open(qualityfile, "w") as g:
                json.dump(self.producerdata, g)
            #print(self.producerdata)
        except TypeError as e:
            error_data = {
                'ts': {
                    'error': 'QG_E105',
                    'description': f"Error serializing to JSON: {e}"
                }
            }
            self.error_to_json(error_data)
            sys.exit()
        except (IOError, OSError) as e:
            error_data = {
                'ts': {
                    'error': 'QG_E106',
                    'description': f"File writing error: {e}"
                }
            }
            self.error_to_json(error_data)
            sys.exit()
        except KeyboardInterrupt as e:
            error_data = {
                'ts': {
                    'error': 'QG_E107',
                    'description': f"An unexpected error occurred: '{e}'"
                }
            }
            self.error_to_json(error_data)
            sys.exit()

    def execute(self):
        """Orchestrates the execution of quality gate evaluations, including data flattening,\
              result extraction, and verdict determination."""
        print(' Step-2: Quality gate calculation started ..')
        temp_inputs = self.get_job_data()
        self.inputs = temp_inputs['qg']
        self.flatit()
        for i in self.inputs.keys():
            if i == 'verdict':
                pass
            else:
                #print('status --> ',self.inputs[i]['status'])
                # Check if test is active
                if self.inputs[i]['status'] == 'active':
                    self.testname = i
                    self.alltests()

                    #Actual input list, Do not delete
                    if len(self.columnnames) == 0:
                        print('ts file is not good')
                    else:
                        self.extract = self.extractresult()
                    #print('extract is ==> ',self.extract)
                    # Process the extract list and get output
                    self.attribute = self.inputs[i]['attrib_value']
                    #print('attrib value', self.inputs[i].keys())
                    self.function1 = self.inputs[i]['function']
                    self.threshold = str(self.inputs[i]['threshold'])
                    self.attributename = self.inputs[i]['attrib']
                    self.attrib_value = (self.inputs[self.testname]['attrib_value'])
                    print("attrib value is --> ", type(self.attrib_value))
                    self.processed = self.processresult()
                    #print('processed ', self.processed)
                    for key in self.processed:
                        #print('processed ', self.processed[key][0])
                        self.producerdata['quality_data'][self.testfilename][self.wname]['qg']\
                            [self.testname]['actual_value'] = str(self.processed[key][0])
                    self.result = self.compareresult()
                    self.preverdict[i] = self.result
                    # Clear list for next output
                    self.columnnames.clear()
                else:
                    del self.producerdata['quality_data'][self.testfilename][self.wname][i]
