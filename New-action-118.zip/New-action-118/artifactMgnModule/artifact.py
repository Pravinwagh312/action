import os
import json
from zipfile import ZipFile
from datetime import datetime
import requests
from requests.auth import HTTPBasicAuth
import subprocess
import sys

class ArtifactDetails:

    def __init__(self,cwd, xmlfilepath):
        self.output_data = {}
        self.xmlfilepath = xmlfilepath
        self.cwd = cwd
        self.artifact_path  = os.path.join(self.cwd, self.xmlfilepath)
        self.error = {}
        # try:
        config_content = os.getenv('CONFIG_JSON')
        if not config_content:
            raise ValueError("Config content is not provided.")
        self.config = json.loads(config_content)
    
        self.nexus_base_url = self.config["nexus"]["nexus_base_url"]
        self.repo = self.config["nexus"]["nexus_repo"]
        self.user = self.config["nexus"]["nexus_user"]
        self.password = self.config["nexus"]["nexus_password"]

        
        # except:
        #     self.error['ts'] = {}
        #     self.error['ts']['error'] = 'AF_E101'
        #     self.error['ts']['description'] = f'Artifact details are not provided in CONFIG_JSON'
        #     self.error_to_json(self.error)
        #     sys.exit()
            

    
    def error_to_json(self, error_data):
        """Writes error details to a JSON file in a specified directory."""
        cwd = os.getcwd()
        errordir = os.path.join(cwd)
        os.makedirs(errordir, exist_ok=True)  # Ensures the directory exists
        err_filename = os.path.join(errordir, "errors.json")
        #error_data = self.error if self.error else {'qg': {'error': 'E0'}}
        with open(err_filename, "w") as f:
            json.dump(error_data, f, indent=4)
        print(error_data)
        print(f"Errors written to: {err_filename}")
        sys.exit()
        

    def get_all_file_paths(self,directory):
        # initializing empty file paths list
        file_paths = []
        # crawling through directory and subdirectories
        if directory:
            for root, directories, files in os.walk(directory):
                _ = directories
                for filename in files:
                    # join the two strings in order to form the full filepath.
                    filepath = os.path.join(root, filename)
                    # print(filepath)
                    file_paths.append(filepath)
            # returning all file paths
            return file_paths
        
    def compressed_artifact_data(self):
        """ function to compress the data into zip file """
        current_date = datetime.now().strftime("%d%m%Y")
        workflow_name = os.getenv("GITHUB_WORKFLOW")
        file_paths = self.get_all_file_paths(self.xmlfilepath)
        new_artifact_name = f'{workflow_name}{current_date}.zip'
        with ZipFile(new_artifact_name, 'w') as zipf:
            for file in file_paths:
                zipf.write(file,os.path.basename(file))
        print(f'{self.artifact_path} has been zipped as {new_artifact_name}')
        return new_artifact_name
    
    def upload_artifacts(self, new_artifact_name):
        """ function to upload artifact to the repository """
        try:
            nexus_url = f"{self.nexus_base_url}repository/{self.repo}/"
#             curl_command = f"curl -v -k -u {self.user}:{self.password} --upload-file {new_artifact_name} {nexus_url}"
            curl_command = f"curl -u {self.user}:{self.password} -T {new_artifact_name} {nexus_url}"
            # print(curl_command)
            curl_command_list = curl_command.split(" ")
            result = subprocess.run(curl_command_list, capture_output=True, text=True, check=True)
            # print(result)
            print(f"Artifact Uploaded Successfully!! {result.stdout}")
        except subprocess.CalledProcessError as error:
            # print(f"Failed to upload artifact with response code {error.stderr}")
            self.error['ts'] = {}
            self.error['ts']['error'] = 'AF_E101'
            self.error['ts']['description'] = f'Failed to upload the artifact details {error.stderr}'
            self.error_to_json(self.error)
            sys.exit()
            raise

    def fetch_artifact_metadata(self,new_artifact_name):
        """ fetching the metadata of artifacts for workflow with the current date """
        self.output_data = {
            "url": self.nexus_base_url,
            "repo_name":os.getenv("GITHUB_REPOSITORY"),
            "branch_name": os.getenv('GITHUB_REF_NAME'),
            "Workflow_Name":os.getenv('GITHUB_WORKFLOW'),
            "Workflow_ID": os.getenv('GITHUB_RUN_ID'),
            # "job_id": job_data['id'],
            "Job_Name": os.getenv("GITHUB_JOB"),
            "artifact_name":new_artifact_name
        }
# #         #Dummy values for local system
#         self.output_data = {
#             "url": "10.52.52.209:8083",
#             "repo_name": "devops",
#             "branch_name": "master",
#             "workflow_name":"CP_Static_Test",
#             "workflow_id": 2571,
#             "run_id": 26512,
#             "job_id": 261652,
#             "job_name": "jobname1",
#             "artifact_name":new_artifact_name
#         }
        # try:
        final_url = f"{self.nexus_base_url}service/rest/v1/components?repository={self.repo}"
        fetch_detail_url = final_url
        # print(final_url)
        all_response_data = []
        # count = 0
        while fetch_detail_url:
            response = requests.get(fetch_detail_url, auth=HTTPBasicAuth(self.user,self.password))
            # print(response.status_code)
            try:
                if response.status_code == 200:
                    response_data = response.json()
                    all_response_data.extend(response_data['items'])
                    data_fetched = False
                    for data in all_response_data:
                        if data["name"] == new_artifact_name:
                            artifact_output_data = data
                            data_fetched = True
                            break
                    if response_data["continuationToken"] and data_fetched == False:
                        fetch_detail_url = f'{final_url}&continuationToken={response_data["continuationToken"]}'
                        # print(fetch_detail_url)
                    else:
                        break
                # else:
                #     print("url is invalid")
                #     break
            except:
                # print(f"Error found as {error}")
                self.error['ts'] = {}
                self.error['ts']['error'] = 'AF_E102'
                self.error['ts']['description'] = f'Failed to fetch the metadata due to {response.status_code}'
                self.error_to_json(self.error)
                sys.exit()

        self.output_data["group"] = artifact_output_data["group"]
        self.output_data["version"] = artifact_output_data["version"]
        self.output_data["Nexus_Repo"] = artifact_output_data["repository"]
        self.output_data["lastModified"] = artifact_output_data["assets"][0]["lastModified"]
        self.output_data["downloadUrl"] = artifact_output_data["assets"][0]["downloadUrl"]
        self.output_data["nexus_info"] = artifact_output_data   
        # print(self.output_data)
        artifact_file = os.path.join(self.cwd,"artifact_output.json")
        with open(artifact_file,"w") as outfile:
            json.dump(self.output_data,outfile,indent=4)
