import os
import json
import logging
import requests
from kafka import KafkaProducer

logging.basicConfig(level=logging.INFO)
LOGGER = logging.getLogger(__name__)


class GitHubKafkaIntegrator:
    """
    A class to integrate GitHub with Kafka.
    """

    def __init__(self, jobname,github_run_id):
        self.jobname1 = jobname
        self.github_run_id = github_run_id
        config_content = os.getenv('CONFIG_JSON')
        if not config_content:
            raise ValueError("Config content is not provided.")
        self.config = json.loads(config_content)
        print(config_content)
        
        self.github_token = os.getenv('GITHUB_TOKEN')
        print(self.github_token)
        if not self.github_token:
            raise ValueError("GitHub token not provided.")

        self.repository = os.getenv('REPOSITORY')
        print(self.repository)
        if not self.repository:
            raise ValueError("Repository not provided.")
        
        # Reading Token, URL and kafka server parameter
        #self.github_token = os.getenv('GITHUB_TOKEN', self.config['github']['token'])
        #self.github_api_url = self.config['github']['enterprise_url']
        # Use the instance method to get the API URL
        self.github_api_url = self.get_github_api_url()
        self.kafka_bootstrap_servers = self.config['kafka']['bootstrap_servers']
        
        # Headers for GitHub API requests
        self.headers = {
            'Authorization': f'token {self.github_token}',
            'Accept': 'application/vnd.github.v3+json',
        }

    def get_workflow_details(self):
        """
        Fetch workflow details from GitHub.
        """
        github_run_id = self.github_run_id
        #github_run_id = os.getenv('GITHUB_RUN_ID')
        github_repository = os.getenv('GITHUB_REPOSITORY')
        run_url = f'{self.github_api_url}/repos/{github_repository}/actions/runs/{github_run_id}'
        run_response = requests.get(run_url, headers=self.headers)
        run_response.raise_for_status()
        return run_response.json()
    
    def get_github_api_url(self):
        server_url = os.getenv('GITHUB_SERVER_URL')
        if server_url:
            api_base_path = "/api/v3"
            return f"{server_url}{api_base_path}"
        else:
            raise ValueError("GITHUB_SERVER_URL environment variable is not set.")

    def get_job_details(self):
        """
        Fetch job details associated with a workflow.
        """
        github_run_id = self.github_run_id
        #github_run_id = os.getenv('GITHUB_RUN_ID')
        print("git hub run ID is --> ", github_run_id)
        github_repository = os.getenv('GITHUB_REPOSITORY')
        #job_name = os.getenv('GITHUB_JOB')
        job_name = self.jobname1
        print("job name inside producer", job_name)
        github_actor = os.getenv('GITHUB_ACTOR')    
        job_url = f'{self.github_api_url}/repos/{github_repository}/actions/runs/{github_run_id}/jobs'
        job_response = requests.get(job_url, headers=self.headers)

        if job_response.status_code != 200:
            LOGGER.error('Failed to get jobs: %s', job_response.status_code)
            return None

        # Find the job from the list of jobs that matches the given job_name
        jobs = job_response.json().get('jobs', [])
        for job in jobs:
            #if job_name == job_name:
            job_temp = (job['name'].split('/')[-1]).strip()
            print("new Job name ---->******* ", job_temp," current job -->", job_name)
            if job_temp == job_name:
                print('I am in ==< ', "new Job name ---->******* ", job_temp," current job -->", job_name)
            #if job['name'] == job_name:
                job['actor'] = github_actor
                return job
        return None

    def merge_json_data(self, workflow_data, job_data):
        """
        Merge data from workflow and job details.
        """
        job_info = {
            "workflow_id": workflow_data['workflow_id'],
            "run_id": self.github_run_id,
            #"run_id": os.getenv('GITHUB_RUN_ID'),
            "job_id": job_data['id'],
            "job_name": job_data['name'],
            "github_actor": os.getenv('GITHUB_ACTOR')
        }

        file_data = {
            'license': os.path.join(os.getenv('GITHUB_WORKSPACE'), 'licenseData.json'),
            'output': os.path.join(os.getenv('GITHUB_WORKSPACE'), 'output.json'),
            'quality': os.path.join(os.getenv('GITHUB_WORKSPACE'), 'quality.json'),
            'artifact':os.path.join(os.getenv('GITHUB_WORKSPACE'), 'artifact_output.json'),
            'error': os.path.join(os.getenv('GITHUB_WORKSPACE'), 'errors.json')
        }

        for filename, filepath in file_data.items():
            try:
                with open(filepath, 'r') as file:
                    data = json.load(file)
                    if filename == 'license':
                        job_info['license'] = data
                        os.remove(file_data['license'])
                    elif filename == 'output':
#                         print("Yes I am in output")
                        job_info['output'] = data
                        os.remove(file_data['output'])
                    elif filename == 'quality':
#                         print("in quality")
                        job_info['quality'] = data
                        os.remove(file_data['quality'])
                    elif filename == 'artifact':
                        job_info['artifact'] = data
                        os.remove(file_data['artifact'])
                    else:  # This is for 'error'
#                         print("in error")
                        job_info['error'] = data
                        os.remove(file_data['error'])
            except FileNotFoundError:
                LOGGER.warning(f'{filename}.json not found at {filepath}, skipping {filename} data merge.')
                
        merged_file_path = os.path.join(os.getenv('GITHUB_WORKSPACE'), 'all_data.json')
        with open(merged_file_path, 'w') as merge_file:
            json.dump(job_info, merge_file, indent=4)

        LOGGER.info(f"Merged data written to {merged_file_path}")

        return job_info

    def send_to_kafka(self, json_data):
        """
        Send merged data to Kafka.
        """
        producer = KafkaProducer(
            bootstrap_servers=self.kafka_bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
        
        # Uncomment below if you wish to send data
        future = producer.send('my_topic1', value=json_data)
        ##return future.get(timeout=60)
        
        future.get(timeout=60)  # Wait for the data to be sent to Kafka
        print("Data successfully sent to Kafka!")  # Print success message
        producer.close()

    def run(self):
        """
        Main execution method.
        """
        workflow_data = self.get_workflow_details()
        job_data = self.get_job_details()
        print("job name inside producer in run loop", job_data)
        

        if not job_data:
            LOGGER.error("Failed to get job details")
            return

        merged_data = self.merge_json_data(workflow_data, job_data)
        json_data = json.dumps(merged_data, indent=4)
        print(json_data)
        print(type(json_data))

        # Save the merged data
        output_json_path = os.path.join(os.getenv('GITHUB_WORKSPACE'), 'alloutput.json')
        with open(output_json_path, 'w') as output_file:
            json.dump(json_data, output_file, indent=4)
            
        print('Data to kafka', json_data)
        # Send merged data to Kafka
        # Uncomment below if you wish to send data
        self.send_to_kafka(merged_data)


# if __name__ == "__main__":
#     INTEGRATOR = GitHubKafkaIntegrator()
#     INTEGRATOR.run()
